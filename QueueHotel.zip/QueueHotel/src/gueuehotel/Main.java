package gueuehotel;

import javax.swing.SwingUtilities;
import java.awt.EventQueue;

/**
 * Main application entry point for the Hotel Reservation System.
 * Initializes the shared system logic and multiple UI frames.
 */
public class Main {

    /**
     * Application entry point. Ensures GUI is launched on the Event Dispatch Thread (EDT).
     *
     * @param args Command line arguments (not used).
     */
    public static void main(String[] args) {
        // Schedule GUI creation on the Event Dispatch Thread (EDT).
        EventQueue.invokeLater(() -> {
            // Create the single shared instance of the hotel reservation system.
            HotelReservationSystem sharedSystem = new HotelReservationSystem();

            // Initialize and display the Admin and User interface frames.
            Frame adminFrame = new Frame("Admin", 1, 1000, 900, sharedSystem);
            adminFrame.setVisible(true);

            Frame userFrame1 = new Frame("User 1", 2, 700, 500, sharedSystem);
            userFrame1.setVisible(true);

            Frame userFrame2 = new Frame("User 2", 3, 700, 500, sharedSystem);
            userFrame2.setVisible(true);
        });
    }
}