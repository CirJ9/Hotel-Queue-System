package gueuehotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.UUID;

public class WaitlistStatusDialog extends JDialog implements HotelReservationSystem.ReservationListener {
    private HotelReservationSystem hotelSystem;
    private Reservation reservation;
    private JLabel statusLabel;
    private JLabel positionLabel;
    private JLabel queueSizeLabel;

    public WaitlistStatusDialog(JFrame parent, HotelReservationSystem system, Reservation res) {
        super(parent, "Waitlist Status", false);
        hotelSystem = system;
        reservation = res;
        
        hotelSystem.addListener(this);

        setLayout(new BorderLayout(10, 10));
        setSize(450, 250);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel infoPanel = new JPanel(new GridLayout(3, 1, 5, 5));
        statusLabel = new JLabel("<html><center>You are currently on the waiting list for " + reservation.getGuestName() + "</center></html>", SwingConstants.CENTER);
        positionLabel = new JLabel("Your Position: Calculating...", SwingConstants.CENTER);
        queueSizeLabel = new JLabel("Total in Queue: Calculating...", SwingConstants.CENTER);
        infoPanel.add(statusLabel);
        infoPanel.add(positionLabel);
        infoPanel.add(queueSizeLabel);
        add(infoPanel, BorderLayout.CENTER);

        JButton cancelButton = new JButton("Cancel Waitlist");
        cancelButton.addActionListener(e -> {
            hotelSystem.cancelWaitlist(reservation.getId());
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(cancelButton);
        add(buttonPanel, BorderLayout.SOUTH);

        updateWaitlistDisplay();
        setVisible(true);
    }

    public void updateWaitlistDisplay() {
        int position = hotelSystem.getWaitlistPosition(reservation.getId());
        int totalQueue = hotelSystem.getWaitlist().size();
        
        if (position == -1) {
            statusLabel.setText("Your reservation has been removed from the waitlist.");
            positionLabel.setText("Your Position: N/A");
            queueSizeLabel.setText("Total in Queue: " + totalQueue);
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(this, "Your reservation has been removed from the waitlist.", "Waitlist Update", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            });
        } else {
            positionLabel.setText("Your Position: " + position);
            queueSizeLabel.setText("Total in Queue: " + totalQueue);
        }
    }
    
    public UUID getReservationId() {
        return reservation.getId();
    }

    @Override
    public void onBookingEvent(HotelReservationSystem.BookingEvent event) {
        
        if (event.getType() == HotelReservationSystem.BookingEvent.EventType.WAITLIST_UPDATE &&
            event.getReservation() != null && event.getReservation().getId().equals(reservation.getId())) {
            SwingUtilities.invokeLater(() -> updateWaitlistDisplay());
        }
        else if (event.getType() == HotelReservationSystem.BookingEvent.EventType.RESERVATION_CANCELLED &&
                   event.getReservation() != null && event.getReservation().getId().equals(reservation.getId())) {
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(this, "Your waitlist position has been cancelled.", "Waitlist Update", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            });
        }
        else if (event.getType() == HotelReservationSystem.BookingEvent.EventType.BOOKING_SUCCESS &&
                 event.getReservation() != null && event.getReservation().getId().equals(reservation.getId())) {
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(this, "Your room has been booked!", "Booking Success", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            });
        }
        else if ((event.getType() == HotelReservationSystem.BookingEvent.EventType.OFFER_DECLINED ||
                  event.getType() == HotelReservationSystem.BookingEvent.EventType.OFFER_TIMEOUT) &&
                 event.getReservation() != null && event.getReservation().getId().equals(reservation.getId())) {
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(this, "Your room offer was processed (declined or timed out).", "Offer Status", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            });
        }
    }
}