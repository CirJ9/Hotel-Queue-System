package gueuehotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Queue;
import java.util.UUID;
import java.util.stream.Collectors;

import gueuehotel.HotelReservationSystem.BookingEvent;
import gueuehotel.HotelReservationSystem.ReservationListener;

public class Panel extends JPanel implements ActionListener, ReservationListener {

    private JTextField guestNameField;
    private JComboBox<String> roomNumberComboBox;
    private JSpinner checkInDateSpinner;
    private JSpinner checkOutDateSpinner;
    private JButton addReservationButton;
    private JTextArea messageArea;

    private JPanel roomsDisplayPanel;
    private JTextArea waitlistDisplayArea;
    private JButton refreshAdminViewButton;
    private JPanel waitlistPanel;

    private HotelReservationSystem hotelSystem;
    private int frameType;
    private SimpleDateFormat dateFormat;

    private UUID associatedReservationId;
    private WaitlistStatusDialog currentWaitlistDialog;

    public Panel(int frameType, HotelReservationSystem system) {
        this.frameType = frameType;
        this.hotelSystem = system;
        this.dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        setLayout(new BorderLayout());

        hotelSystem.addListener(this);

        if (frameType == 1) {
            setupAdminPanel();
        } else {
            setupUserPanel();
        }
    }

    public UUID getAssociatedReservationId() {
        return associatedReservationId;
    }
    public int getFrameType() {
        return frameType;
    }

    private void setupAdminPanel() {
        JPanel mainAdminPanel = new JPanel(new BorderLayout());

        mainAdminPanel.add(new JLabel("Hotel Reservation System - Admin View", SwingConstants.CENTER), BorderLayout.NORTH);
        
        roomsDisplayPanel = new JPanel();
        roomsDisplayPanel.setLayout(new BoxLayout(roomsDisplayPanel, BoxLayout.Y_AXIS));

        JScrollPane roomsScrollPane = new JScrollPane(roomsDisplayPanel);
        roomsScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        roomsScrollPane.setBorder(BorderFactory.createTitledBorder("Rooms Status"));

        waitlistPanel = new JPanel(new BorderLayout());
        waitlistPanel.setBorder(BorderFactory.createTitledBorder("WAITLIST"));
        waitlistDisplayArea = new JTextArea(10, 20);
        waitlistDisplayArea.setEditable(false);
        waitlistPanel.add(new JScrollPane(waitlistDisplayArea), BorderLayout.CENTER);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, roomsScrollPane, waitlistPanel);
        splitPane.setResizeWeight(0.7);
        mainAdminPanel.add(splitPane, BorderLayout.CENTER);

        JPanel bottomAdminPanel = new JPanel(new BorderLayout());
        
        refreshAdminViewButton = new JButton("Refresh View");
        refreshAdminViewButton.addActionListener(this);
        JPanel refreshButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        refreshButtonPanel.add(refreshAdminViewButton);
        bottomAdminPanel.add(refreshButtonPanel, BorderLayout.NORTH);

        messageArea = new JTextArea(3, 30);
        messageArea.setEditable(false);
        JScrollPane adminMessageScrollPane = new JScrollPane(messageArea);
        adminMessageScrollPane.setBorder(BorderFactory.createTitledBorder("Admin Messages"));
        bottomAdminPanel.add(adminMessageScrollPane, BorderLayout.CENTER);
        
        mainAdminPanel.add(bottomAdminPanel, BorderLayout.SOUTH);

        add(mainAdminPanel, BorderLayout.CENTER);
        updateAdminDisplay();
    }

    private void updateAdminDisplay() {
        roomsDisplayPanel.removeAll();

        hotelSystem.getAllRooms().entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .forEach(entry -> {
                    Room room = entry.getValue();
                    roomsDisplayPanel.add(createRoomPanel(room));
                    roomsDisplayPanel.add(Box.createRigidArea(new Dimension(0, 10)));
                });

        displayWaitlist();
        roomsDisplayPanel.revalidate();
        roomsDisplayPanel.repaint();
    }

    private JPanel createRoomPanel(Room room) {
        JPanel roomPanel = new JPanel(new BorderLayout());
        roomPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1, true));
        roomPanel.setPreferredSize(new Dimension(roomPanel.getPreferredSize().width, 100));

        JLabel roomInfoLabel = new JLabel("ROOM " + room.getRoomNumber() + " STATUS: " + room.getRoomStatus());
        JLabel customerLabel = new JLabel("CUSTOMER: " + (room.getCurrentReservation() != null ? room.getCurrentReservation().getGuestName() : "N/A"));

        JPanel infoPanel = new JPanel(new GridLayout(2, 1));
        infoPanel.add(roomInfoLabel);
        infoPanel.add(customerLabel);
        roomPanel.add(infoPanel, BorderLayout.WEST);

        JButton clearButton = new JButton("CLEAR");
        clearButton.setActionCommand("CLEAR_ROOM_" + room.getRoomNumber());
        clearButton.addActionListener(this);
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(clearButton);
        roomPanel.add(buttonPanel, BorderLayout.EAST);

        return roomPanel;
    }

    private void displayWaitlist() {
        waitlistDisplayArea.setText("");
        Queue<Reservation> waitlist = hotelSystem.getWaitlist();
        if (waitlist.isEmpty()) {
            waitlistDisplayArea.setText("No customers on waitlist.");
        } else {
            StringBuilder sb = new StringBuilder("WAITLIST:\n");
            waitlist.stream()
                    .map(Reservation::getGuestName)
                    .collect(Collectors.toList())
                    .forEach(guestName -> sb.append("- ").append(guestName).append("\n"));
            waitlistDisplayArea.setText(sb.toString());
        }
    }

    private void setupUserPanel() {
        JPanel userContentPanel = new JPanel();
        userContentPanel.setLayout(new GridLayout(0, 2, 10, 10));

        add(new JLabel("Add New Reservation", SwingConstants.CENTER), BorderLayout.NORTH);

        userContentPanel.add(new JLabel("Guest Name:"));
        guestNameField = new JTextField(20);
        userContentPanel.add(guestNameField);

        userContentPanel.add(new JLabel("Desired Room (optional):"));
        roomNumberComboBox = new JComboBox<>();
        roomNumberComboBox.addItem("Any Room");
        hotelSystem.getAllRooms().keySet().stream()
                       .sorted()
                       .forEach(roomNumber -> roomNumberComboBox.addItem(String.valueOf(roomNumber)));
        userContentPanel.add(roomNumberComboBox);

        userContentPanel.add(new JLabel("Check-in Date:"));
        checkInDateSpinner = new JSpinner(new SpinnerDateModel());
        checkInDateSpinner.setEditor(new JSpinner.DateEditor(checkInDateSpinner, "dd-MM-yyyy"));
        userContentPanel.add(checkInDateSpinner);

        userContentPanel.add(new JLabel("Check-out Date:"));
        checkOutDateSpinner = new JSpinner(new SpinnerDateModel());
        checkOutDateSpinner.setEditor(new JSpinner.DateEditor(checkOutDateSpinner, "dd-MM-yyyy"));
        userContentPanel.add(checkOutDateSpinner);

        addReservationButton = new JButton("Add Reservation to Queue");
        addReservationButton.addActionListener(this);
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(addReservationButton);
        
        messageArea = new JTextArea(3, 30);
        messageArea.setEditable(false);
        JScrollPane messageScrollPane = new JScrollPane(messageArea);
        
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(buttonPanel, BorderLayout.NORTH);
        bottomPanel.add(messageScrollPane, BorderLayout.CENTER);

        add(userContentPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void addReservation() {
        String guestName = guestNameField.getText().trim();
        String selectedRoomStr = (String) roomNumberComboBox.getSelectedItem();
        Date checkInDateObj = (Date) checkInDateSpinner.getValue();
        Date checkOutDateObj = (Date) checkOutDateSpinner.getValue();

        if (guestName.isEmpty()) {
            messageArea.setText("Please enter Guest Name.");
            return;
        }
        if (checkInDateObj.after(checkOutDateObj)) {
            messageArea.setText("Check-out date cannot be before Check-in date.");
            return;
        }

        String checkInDateStr = dateFormat.format(checkInDateObj);
        String checkOutDateStr = dateFormat.format(checkOutDateObj);

        int desiredRoom = 0;
        if (selectedRoomStr != null && !selectedRoomStr.equals("Any Room")) {
            try {
                desiredRoom = Integer.parseInt(selectedRoomStr);
                if (hotelSystem.getRoom(desiredRoom) == null) {
                    messageArea.setText("Room " + desiredRoom + " does not exist. Attempting to book any available room or join waitlist.");
                    desiredRoom = 0;
                }
            } catch (NumberFormatException ex) {
                desiredRoom = 0;
            }
        }

        Reservation newReservation = new Reservation(guestName, desiredRoom, checkInDateStr, checkOutDateStr);
        associatedReservationId = newReservation.getId();
        
        hotelSystem.addReservation(newReservation);
        clearInputFields();
    }

    private void clearInputFields() {
        guestNameField.setText("");
        roomNumberComboBox.setSelectedIndex(0);
        checkInDateSpinner.setValue(new Date());
        checkOutDateSpinner.setValue(new Date());
    }

    private void showDialog(JDialog dialog) {
        SwingUtilities.invokeLater(() -> dialog.setVisible(true));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addReservationButton) {
            addReservation();
        } else if (e.getSource() == refreshAdminViewButton) {
            updateAdminDisplay();
        } else if (e.getActionCommand().startsWith("CLEAR_ROOM_")) {
            int roomNumberToClear = Integer.parseInt(e.getActionCommand().substring("CLEAR_ROOM_".length()));
            hotelSystem.clearRoom(roomNumberToClear);
            updateAdminDisplay();
        }
    }

    @Override
    public void onBookingEvent(BookingEvent event) {
        SwingUtilities.invokeLater(() -> {
            if (frameType == 1) {
                updateAdminDisplay();
                messageArea.setText("Admin event: " + event.getType() + " for " + (event.getReservation() != null ? event.getReservation().getGuestName() : "N/A") + ". Room: " + (event.getRoomNumber() != 0 ? event.getRoomNumber() : "N/A") + ".");
            } else {
                if (event.getReservation() != null &&
                    (event.getReservation().getId().equals(associatedReservationId) ||
                     (currentWaitlistDialog != null && currentWaitlistDialog.getReservationId().equals(event.getReservation().getId())))) {

                    JFrame parentFrame = (JFrame) SwingUtilities.getWindowAncestor(this);

                    switch (event.getType()) {
                        case BOOKING_SUCCESS:
                            showDialog(new BookingSuccessDialog(parentFrame, event.getReservation(), event.getRoomNumber()));
                            messageArea.setText("Booking successful for Room " + event.getRoomNumber() + "!");
                            if (currentWaitlistDialog != null) {
                                currentWaitlistDialog.dispose();
                                currentWaitlistDialog = null;
                            }
                            associatedReservationId = null;
                            break;

                        case JOINED_WAITLIST:
                            messageArea.setText("All rooms are full. You have been added to the waitlist.");
                            if (currentWaitlistDialog == null || !currentWaitlistDialog.getReservationId().equals(event.getReservation().getId())) {
                                currentWaitlistDialog = new WaitlistStatusDialog(parentFrame, hotelSystem, event.getReservation());
                                showDialog(currentWaitlistDialog);
                            } else {
                                currentWaitlistDialog.updateWaitlistDisplay();
                                if (!currentWaitlistDialog.isShowing()) {
                                    showDialog(currentWaitlistDialog);
                                }
                            }
                            associatedReservationId = event.getReservation().getId();
                            break;

                        case WAITLIST_UPDATE:
                            if (currentWaitlistDialog != null && currentWaitlistDialog.getReservationId().equals(event.getReservation().getId())) {
                                currentWaitlistDialog.updateWaitlistDisplay();
                                if (hotelSystem.getWaitlistPosition(event.getReservation().getId()) == -1) {
                                    if (currentWaitlistDialog.isShowing()) {
                                        JOptionPane.showMessageDialog(currentWaitlistDialog, "Your waitlist status has changed. Please check for new offers or if your reservation was fulfilled/cancelled.", "Waitlist Update", JOptionPane.INFORMATION_MESSAGE);
                                        currentWaitlistDialog.dispose();
                                        currentWaitlistDialog = null;
                                        associatedReservationId = null;
                                    }
                                }
                            } else if (associatedReservationId != null && hotelSystem.getWaitlistPosition(associatedReservationId) == -1) {
                                messageArea.setText("Your waitlisted reservation has been fulfilled or cancelled externally.");
                                associatedReservationId = null;
                                if (currentWaitlistDialog != null) {
                                    currentWaitlistDialog.dispose();
                                    currentWaitlistDialog = null;
                                }
                            }
                            break;

                        case ROOM_OFFERED:
                            showDialog(new RoomOfferDialog(parentFrame, hotelSystem, event.getReservation(), event.getRoomNumber()));
                            messageArea.setText("Room " + event.getRoomNumber() + " is now offered to you!");
                            if (currentWaitlistDialog != null) {
                                currentWaitlistDialog.dispose();
                                currentWaitlistDialog = null;
                            }
                            associatedReservationId = event.getReservation().getId();
                            break;

                        case OFFER_DECLINED:
                        case OFFER_TIMEOUT:
                            messageArea.setText("Your room offer for Room " + event.getRoomNumber() + " was " +
                                                (event.getType() == BookingEvent.EventType.OFFER_DECLINED ? "declined." : "timed out."));
                            if (hotelSystem.getWaitlistPosition(event.getReservation().getId()) == -1) {
                                 associatedReservationId = null;
                            }
                            if (currentWaitlistDialog != null) {
                                currentWaitlistDialog.dispose();
                                currentWaitlistDialog = null;
                            }
                            break;

                        case RESERVATION_CANCELLED:
                            messageArea.setText("Your reservation for " + event.getReservation().getGuestName() + " has been cancelled.");
                            associatedReservationId = null;
                            if (currentWaitlistDialog != null) {
                                currentWaitlistDialog.dispose();
                                currentWaitlistDialog = null;
                            }
                            break;
                    }
                }
            }
        });
    }
}